document.body.style.background = "black";
document.body.style.font = "white";
